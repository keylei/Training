//#include "MySpace.hpp"

//MySpace::MySpace()
//{

//}
