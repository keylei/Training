#ifndef HUMAN_HPP
#define HUMAN_HPP

#include "chrono"
#include <iostream>

namespace Mammal
{
class Human
{
public:
    Human();
};
}//End of namespace Mammal

#endif // HUMAN_HPP
