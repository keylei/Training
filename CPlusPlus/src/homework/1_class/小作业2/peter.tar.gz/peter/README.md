
## build Settings

-  debug模式

	将编译路径由默认改为项目根目录
	Build directory : ../debug

- release模式

	将编译路径由默认改为项目根目录
	Build directory : ../release

