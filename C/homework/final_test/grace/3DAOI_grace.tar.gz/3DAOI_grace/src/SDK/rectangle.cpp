#include "SDK/rectangle.hpp"

using namespace SDK;

Rectangle::Rectangle()
{

}

Rectangle::Rectangle(double xCoord, double yCoord, double width, double height)
{
    this->m_xCoord = xCoord;
    this->m_yCoord = yCoord;
    this->m_width = width;
    this->m_height = height;
}

Rectangle::~Rectangle()
{

}
