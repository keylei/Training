#include "Job/measuredObjList.hpp"
#include "Job/measuredObj.hpp"

using namespace Job;
using namespace std;

MeasuredObjList::MeasuredObjList()
{

}

MeasuredObjList::~MeasuredObjList()
{
    this->m_pHead = nullptr;
}

void MeasuredObjList::pushHeadNode(MeasuredObj *ptr)
{
    MeasuredObj *pOrigPos = this->m_pHead; //保存链表头地址
    this->m_pHead = ptr;     //将待插入节点设为首个节点
    ptr->setPNext(pOrigPos); //链表后一节点设为原来的头节点
    if(pOrigPos != nullptr)  //链表不为空
    {
        pOrigPos->setPPre(ptr);
    }
    this->m_size ++;         //节点个数增一
}

void MeasuredObjList::pushTailNode(MeasuredObj *ptr)
{
    MeasuredObj *pOrigPos = this->m_pHead; //保存头地址
    //如果之前链表为空，直接插入，链表长度增1
    if(this->m_pHead == nullptr)
    {
        this->m_pHead = ptr;
        ptr->setPNext(nullptr);
        ptr->setPPre(nullptr);
        this->m_size ++; //链表长度加1
        return;
    }
    //如果之前链表不为空，找到最后一个元素在后面插入目标节点，链表长度增1
    while (this->m_pHead->pNext() != nullptr)
    {
        this->m_pHead = this->m_pHead->pNext();
    }

    this->m_pHead->setPNext(ptr); //在链表最后一个节点插入目标节点
    ptr->setPPre(this->m_pHead);
    ptr->setPNext(nullptr);

    this->m_pHead = pOrigPos; //还原头地址
    this->m_size ++;          //链表长度加1
}

void MeasuredObjList::pullHeadNode()
{
    if(this->m_pHead == nullptr) //如果链表为空，直接退出
    {
        return;
    }
    MeasuredObj *pOrigPos = this->m_pHead; //链表不为空，删除第一个节点
    this->m_pHead = this->m_pHead->pNext();
    if(pOrigPos->pNext() != nullptr)
    {
       pOrigPos->pNext()->setPPre(nullptr);
    }
    this->m_size --; //链表长度减1
}

void MeasuredObjList::pullTailNode()
{
    if(this->m_pHead == nullptr) //链表为空，直接退出
    {
        return;
    }
    MeasuredObj *pDelete;
    pDelete = this->m_pHead;
    while (pDelete->pNext() != nullptr) //找到最后一个节点
    {
        pDelete = (*pDelete).pNext();
    }
    if(pDelete->pPre() != nullptr) //如果链表有多个一个节点
    {
        pDelete->pPre()->setPNext(nullptr);
        pDelete->setPPre(nullptr);
        pDelete->setPNext(nullptr);
    }
    else //链表只有一个节点
    {
        this->m_pHead = nullptr;
    }
    this->m_size --; //链表长度加1
}

void MeasuredObjList::print()
{
    MeasuredObj *pTemp;
    pTemp = this->m_pHead;
    while (pTemp != nullptr) //遍历所有节点
    {
        cout << (*pTemp).name() << endl;
        cout << "  " << "x坐标：" << (*pTemp).body().xCoord() << endl;
        cout << "  " << "y坐标：" << (*pTemp).body().yCoord() << endl;
        cout << "  " << "板子高度：" << (*pTemp).body().height() << endl;// rime -1 请问这和板子有啥关系
        cout << "  " << "板子宽度：" << (*pTemp).body().width() << endl;
        cout << endl;
        pTemp = pTemp->pNext();
    }
    cout << endl;
}
