#include "Job/measuredObj.hpp"

using namespace Job;

MeasuredObj::MeasuredObj()
{

}

MeasuredObj::~MeasuredObj()
{

}

