#include "captureSetting.hpp"

using namespace App;

CaptureSetting::CaptureSetting()
{

}

CaptureSetting::~CaptureSetting()
{

}

void CaptureSetting::load(const QString &path)
{
    try
    {
        if(!QFile::exists(path)) //假如路径不存在的话, 抛出异常
        {
            THROW_EXCEPTION("没有标定文件");//rime -1 说过的问题：这里不要突然出现标定文件
        }
        else //文件路径存在, 判断文件内容是否正确，不正确则抛出异常
        {
            QSettings configFile(path, QSettings::IniFormat);

            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //step1. 读取图像的宽度,若数据异常则抛出异常

            int width =  configFile.value("Image/Width").toInt();
            if(width == 4096)//rime -1 说过的问题：这里出现魔数，用变量代替
            {
                this->m_imgWidth = width;
            }
            else
            {
                THROW_EXCEPTION("读取ImgWidth失败!");//rime -1 这里写ImgWidth，下面怎么又是Image/Height了呢，你要统一 啊
            }

            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //step2. 读取图像的高度，若数据异常则抛出异常

            int height =  configFile.value("Image/Height").toInt();
            if(height == 3072)
            {
                this->m_imgHeight = height;
            }
            else
            {
                THROW_EXCEPTION("读取Image/Height失败!");
            }

            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //step3. 读取图像位数，若数据异常则抛出异常

            int imgBit =  configFile.value("Image/Bit").toInt();
            if( imgBit == 8 )//rime -1 说过的问题：用了枚举，为什么配置文件存的还是数字
            {
                this->m_imgBit = ImgBit::BIT8;
            }
            else if ( imgBit == 16 )
            {
                this->m_imgBit = ImgBit::BIT16;
            }
            else
            {
                THROW_EXCEPTION("读取Image/Height失败!");
            }
        }//End of else(路径不存在)
    }
    catch(const SDK::CustomException& ex)
    {
        THROW_EXCEPTION(ex.what()); //抛出异常
    }
}
