#ifndef GENERATIONDATA_HPP
#define GENERATIONDATA_HPP

#include "Job/measuredObj.hpp"
#include "Job/board.hpp"
#include "Job/inspectionData.hpp"

#define MEASURED_OBJ_CNT 50 //测量对象数量
#define FILE_NAME_LEN    20 //文件名长度
#define RANDOM_NUM(MAX,MIN) (float)(rand()%((int)(MAX-MIN)*100)+MIN*100)/100 //随机生成大小在MAX和MIN之间的浮点型数据

namespace App
{
/**
 *  @brief 数据生成器
 *         生成程式所有数据
 *
 *  @author grace
 *  @version 1.00 2017-11-29 grace
 *                note:create it
 */
class DataGenerator
{
public:

    //>>>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructor & destructor

    DataGenerator();
    ~DataGenerator();

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //>>>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //operate function

    /*
    *  @brief generateJob:生成程式数据
    *         程式数据包括：
    *           1. 基板的信息
    *           2. 测量对象的信息
    *           3. 版本
    *           4. 最后一次编辑时间
    *  @param inspectionData：检测信息
    *         measuredObjArr：测量对象数组//rime -1 指针的话需要加p作为前缀
    *         arrSize：测量对象数组大小  //rime 大小的话，使用len更好， size容易理解为大小
    *  @return NA
    */
    void generateJob(Job::InspectionData& inspectionData, Job::MeasuredObj *measuredObjArr, int arrSize);

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

};
}

#endif // GENERATIONDATA_HPP
