#ifndef MAINWINDOW_HPP
#define MAINWINDOW_HPP

#include <iostream>
#include <QDir>

#include "DB/sqlitedb.hpp"

#include "App/appSetting.hpp"
#include "App/captureSetting.hpp"
#include "Job/inspectionData.hpp"
#include "App/dataGenerator.hpp"

namespace App
{
/**
 *  @brief MainWindow
 *         1. 加载所有配置文件
 *         2. 加载程式
 *         3. 导出xml文件
 *         4. 并打印检测信息
 *
 *  @author author
 *  @version 1.00 2017-12-06 author
 *                note:create it
 */
class MainWindow
{
public:

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //constructor & destructor

    MainWindow();
    virtual ~MainWindow();

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //get and set function

    Job::InspectionData& inspectionData() {return this->m_inspectionData;}

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //operate function //rime -1 怎么啥都叫operate函数，既然有成员变量了，这里最大的region应该是成员函数，然后有必要再进一步细分

    //rime -1 像load函数比较相近的可以放在一起，可以紧挨着不同空行，然后和其它部分再空行，这样看上去更加工整

    /*
    *  @brief 加载captureSetting.ini文件
    *  @param path：文件路径
    *  @return NA
    */
    void loadCaptureSetting(const QString & path);

    /*
    *  @brief 加载appSetting.ini文件
    *  @param path：文件路径
    *  @return NA
    */
    void loadAppSetting(const QString& path);

    /*
    *  @brief 写程式到xml
    *  @param path：xml文件的路径
    *  @return NA
    */
    void writeToXml(const QString& path);

    /*
    *  @brief 创建程式到数据库
    *  @param path：写程式所在路径  //rime -1 这里不明明是个sqlit
    *  @return NA
    */
    void createJob(SSDK::DB::SqliteDB& sqlite);

    /*
    *  @brief 读程式
    *  @param measuredObjArr[]:存放从数据库读取出的测量对象
    *         sqlite:传入已打开的数据库
    *  @return NA
    */
    void readJob(Job::MeasuredObj measuredObjArr[], SSDK::DB::SqliteDB& sqlite);

    /*
    *  @brief 加载程式所在文件
    *         1.如果有程式文件
    *         2.如果没有程式文件，生成默认程式文件
    *  @param NA
    *  @return NA
    */
    void loadJobFolder();//rime -1 如果说上面的load都是代表读取一个文件的话，那么为了概念的一致，这里扫描目录就不应该用load这个词汇了

private:

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //member variant

    //rime -1 成员变量没有任何的注释

    AppSetting m_appSetting;
    CaptureSetting m_captureSetting;
    Job::InspectionData m_inspectionData;

};
}

#endif // MAINWINDOW_HPP
