#include "mainWindow.hpp"

using namespace std;
using namespace SSDK;
using namespace SSDK::DB;
using namespace App;


MainWindow::MainWindow()
{

}

MainWindow::~MainWindow()
{

}

void MainWindow::loadCaptureSetting(const QString & path)
{
    this->m_captureSetting.load(path);
}

void MainWindow::loadAppSetting(const QString & path)
{
    this->m_appSetting.load(path);
}

void MainWindow::writeToXml(const QString & path)
{
    this->m_inspectionData.writeToXml(path);
}

//rime -1 这个叫createJob不合适，因为Job表达的是整个数据结构，而这个函数仅仅是把现成的数据结构写入sqlite数据结构
void MainWindow::createJob(SqliteDB &sqlite)//rime -1 引用符号离类型更近一点
{
    try
    {
        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step1. 创建job表

        std::string sqlcreate = "create table Job ( version varchar(6), lastEditTime varchar(50) )";
        sqlite.execute(sqlcreate); //新建表 //rime -1 这种注释有何意义，下面也是一样
        std::string sqlInsert = "insert into Job(version,lastEditTime) values(?,?)"; //插入数据
        sqlite.execute(sqlInsert,this->m_inspectionData.version(), this->m_inspectionData.lastEditingTime());

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step2. 创建board表

        sqlcreate = "create table Board (name varchar(50),sizeX REAL,sizeY REAL,originalX REAL,originalY REAL)";
        sqlite.execute(sqlcreate); //新建表
        sqlInsert = "insert into Board(name,sizeX,sizeY,originalX,originalY) values(?,?,?,?,?)"; //插入数据
        sqlite.execute(sqlInsert, this->m_inspectionData.board().name(),
                       this->m_inspectionData.board().sizeX(),
                       this->m_inspectionData.board().sizeY(),
                       this->m_inspectionData.board().originalX(),
                       this->m_inspectionData.board().originalY());

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step3. 创建MeasuredObjs表

        sqlcreate = "create table MeasuredObjs (name varchar(50),width REAL,height REAL,xCoord REAL,yCoord REAL)";
        sqlite.execute(sqlcreate); //新建表
        sqlInsert = "insert into MeasuredObjs(name,width,height,xCoord,yCoord) values(?,?,?,?,?)"; //插入数据
        Job::MeasuredObj* pListHead = this->m_inspectionData.board().measuredObjList().headMeasuredObjs();
        sqlite.prepare(sqlInsert);
        sqlite.begin();
        while (nullptr != pListHead)    //循环插入所有元件的数据
        {
            sqlite.executeWithParms(pListHead->name().data(),
                                    pListHead->body().width(),
                                    pListHead->body().height(),
                                    pListHead->body().xCoord(),
                                    pListHead->body().yCoord());
            pListHead = pListHead->pNext();
        }
    }
    catch(const SDK::CustomException& ex)
    {
        if(sqlite.isOpened())
        {
            sqlite.reset();
            sqlite.close();
        }
        THROW_EXCEPTION(ex.what());
    }
}

void MainWindow::readJob(Job::MeasuredObj measuredObjArr[], SqliteDB &sqlite)
{
    try
    {
        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step1. 读取版本号

        std::string selectedString = "select version from Job";
        sqlite.prepare(selectedString);
        this->m_inspectionData.setVersion(sqlite.executeScalar<std::string>(selectedString));


        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step2. 读取最后检测时间

        selectedString = "select lastEditTime from Job";
        sqlite.prepare(selectedString);
        this->m_inspectionData.setLastEditingTime(sqlite.executeScalar<std::string>(selectedString));


        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step3. 读取Board表

        selectedString = "select * from Board";
        sqlite.prepare(selectedString);
        sqlite.begin();

        while(true)
        {
            sqlite.step();
            if (sqlite.latestErrorCode() == SQLITE_DONE)
            {
                break;
            }
            //保存读取的数据
            this->m_inspectionData.board().setName(boost::get<std::string>(sqlite.columnValue(0)));
            this->m_inspectionData.board().setSizeX(boost::get<double>(sqlite.columnValue(1)));
            this->m_inspectionData.board().setSizeY(boost::get<double>(sqlite.columnValue(2)));
            this->m_inspectionData.board().setOriginalX(boost::get<double>(sqlite.columnValue(3)));
            this->m_inspectionData.board().setOriginalY(boost::get<double>(sqlite.columnValue(4)));
        }


        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //4.读取measuredObjs表

        selectedString = "select * from MeasuredObjs";
        sqlite.prepare(selectedString);
        sqlite.begin();

        Job::MeasuredObj *pQueryingObj;    //正在读取的元件信息
        int i = 0;
        while(true)
        {
            sqlite.step();
            if (sqlite.latestErrorCode() == SQLITE_DONE)
                break;

            //保存读取的数据
            pQueryingObj = (Job::MeasuredObj*)&(measuredObjArr[i]);
            pQueryingObj->setName(boost::get<std::string>(sqlite.columnValue(0)));
            pQueryingObj->body().setWidth(boost::get<double>(sqlite.columnValue(1)));
            pQueryingObj->body().setHeight(boost::get<double>(sqlite.columnValue(2)));
            pQueryingObj->body().setXCoord(boost::get<double>(sqlite.columnValue(3)));
            pQueryingObj->body().setYCoord(boost::get<double>(sqlite.columnValue(4)));
            this->m_inspectionData.board().measuredObjList().pushTailNode(pQueryingObj);
            i++;
        }

    }
    catch(const SDK::CustomException& ex)
    {
        if(sqlite.isOpened())
        {
            sqlite.reset();
            sqlite.close();
        }
        THROW_EXCEPTION(ex.what());
    }
}

void MainWindow::loadJobFolder()
{
    try
    {
        QDir dir(QString::fromStdString(this->m_appSetting.jobFolderPath()));

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step1. 判断文件夹是否存在，不存在则创建

        if(!dir.exists())
        {
            QString path = dir.absolutePath();
            //文件夹不存在，判断是否创建成功，不成功则抛出异常
            if( !dir.mkpath(path) )
            {
                THROW_EXCEPTION("程式路径不存在且创建失败!");
            }
        }

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step2. 创建过滤器列表，过滤xml、txt、o为后缀的文件

        QStringList filters;
        filters << "*[^xml|^txt|^o]";
        dir.setNameFilters(filters);
        dir.setFilter(QDir::Files);

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //step3. 把程式文件写到xml文件并打印相应程式信息
        //1. 判断有没有程式文件。如果没有程式文件，生成默认程式文件，有则打印出程式文件让用户选择
        //2. 把程式文件导成xml
        //3. 打印相关程式

        QFileInfoList list = dir.entryInfoList(); //目录列表
        QFileInfo fileInfo; //记录用户选择的序号所在的程式名
        std::string xmlSuffix = ".xml"; //xml文件后缀名

        if(list.empty())
        {
            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //3.1 没有程式文件，生成默认程式文件，导出xml，打印

            Job::MeasuredObj measuredObjArr[MEASURED_OBJ_CNT]={};
            DataGenerator jobData;

            //生成程式文件
            jobData.generateJob(this->inspectionData(),measuredObjArr,MEASURED_OBJ_CNT);

            //创建程式
            SqliteDB v1Sqlite;
            v1Sqlite.open(this->m_appSetting.jobFolderPath()
                          + this->inspectionData().board().name());

            this->createJob(v1Sqlite);

            v1Sqlite.commit();
            v1Sqlite.close(); //关闭数据库

            //写到xml文件
            this->writeToXml(QString::fromStdString(this->m_appSetting.jobFolderPath()
                                                    + this->inspectionData().board().name()
                                                    + xmlSuffix));

            //在屏幕上打印
            this->m_inspectionData.printInspectionData();
        }
        else
        {
            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //3.2 有程式文件则打印出程式文件让用户选择，并导出xml，打印

            //3.2.1 打印所有的程式名

            for (int i = 0; i < list.size(); ++i)
            {
                fileInfo = list.at(i);
                std::cout<< i << ":\t" << fileInfo.fileName().toStdString() <<std::endl;
            }
            std::cout << "请输入序号选择程式：" << std::endl;

            //>>>-------------------------------------------------------------------------------------------------------------------------------------
            //3.2.2 把用户选择的程式导出成xml并打印

            int index = 0; //用户输入的程式索引
            while (true)
            {
                std::cin >> index;

                if(!cin.fail() && index < list.size() && index >= 0)
                {
                    //>>>-------------------------------------------------------------------------------------------------------------------------------------
                    //3.2.2.1 用户输入符合要求

                    //记录用户选择的序号所在的程式名
                    fileInfo = list.at(index);

                    //打开数据库
                    SqliteDB sqlite;
                    sqlite.open(fileInfo.filePath().toStdString());

                    //获取程式中测量目标的数量
                    std::string sqlQuery = "select count(*) from MeasuredObjs";
                    sqlite.prepare(sqlQuery);
                    int objCnt = sqlite.executeScalar<int>(sqlQuery);

                    //加载用户选择的程式文件：
                    Job::MeasuredObj measuredObjArr[objCnt];
                    readJob(measuredObjArr,sqlite);

                    //关闭数据库
                    sqlite.reset();
                    sqlite.close();

                    //导出xml
                    this->writeToXml(QString::fromStdString(this->m_appSetting.jobFolderPath()
                                                            + fileInfo.fileName().toStdString()
                                                            + xmlSuffix));

                    //打印读取的程式信息
                    this->m_inspectionData.printInspectionData();

                    //将程式数据导出为xml文件
                    this->writeToXml( QString::fromStdString(this->m_appSetting.jobFolderPath() +
                                                             fileInfo.fileName().toStdString() +
                                                             xmlSuffix ));
                    break;

                }//End of if(!cin.fail() && index < list.size() && index >= 0)
                else
                {
                    //>>>-------------------------------------------------------------------------------------------------------------------------------------
                    //3.2.2.2 用户输入不符合要求

                    std::cout << "请重新输入索引！" << std::endl;
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                }

            }//End of while(true)
        }//End of else(没有检测程式)
    }
    catch(const SDK::CustomException& ex)
    {
        THROW_EXCEPTION(ex.what());
    }
}
