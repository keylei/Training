#ifndef APPSETTING_HPP
#define APPSETTING_HPP

#include <iostream>
#include <fstream>
#include <QSettings>
#include <QFile>

#include "SDK/customException.hpp"

namespace App
{
/**
 *  @brief CaptureSetting   //rime -1 为什么类是AppSetting，这里是CaptureSetting
 *         作用：加载配置文件（可修改,可自动生成）//rime -1 应该描述这个类有哪些成员，以及需要注意的地方 你这样写谁能看明白
 *
 *  @author author //rime -1 这种一开始敲snippet的时候就应该改掉，留到最后肯定忘记
 *  @version 1.00 2017-12-06 author
 *                note:create it
 */
class AppSetting
{
public:
    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //enum variant class

    //rime -1 枚举是一种类型，不是变量，如果像Theme theme，那么theme就是枚举变量，这个一定要分清楚
    //rime -1 枚举没有任何注释

    enum class Theme
    {
        BLACK,
        WHITE
    };
    enum class Lang
    {
        CN,
        EN
    };
    enum class LaneMode
    {
        SIMULATOR,
        SINGLE_LANE,
        DUAL_LANE
    };
    enum class MachineType
    {
        SPI,
        AOI3D
    };

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //constructor & destuctor

    AppSetting();
    virtual ~AppSetting();

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //get & set function

    //rime -1 为什么有么companyName的访存函数，却没有Theme等其它的，他们难道不是并列的么

    std::string companyName() {return this->m_companyName;}
    void setCompanyName(std::string companyName) {this->m_companyName = companyName;}

    std::string jobFolderPath() {return this->m_jobFolderPath;}
    void setJobFolderPath(std::string jobFolderPath) {this->m_jobFolderPath = jobFolderPath;}

    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //operate function

    //rime -1
    //这种成员函数都不加注释， 如果觉得load这种一眼看懂，但至少得把流程以一些注意点交代下把，
    //就不能写函数的时候先把snippet加上么？这样就不会遗漏了
    void load(const QString& path);

private:
    //>>>-------------------------------------------------------------------------------------------------------------------------------------
    //member variant

    Theme m_theme{Theme::BLACK};
    Lang m_lang{Lang::CN};
    LaneMode m_laneMode{LaneMode::SIMULATOR};
    MachineType m_machineType{MachineType::SPI};
    std::string m_companyName{"Scijet"};
    std::string m_jobFolderPath{"./Job/"};
};
}

#endif // APPSETTING_HPP
