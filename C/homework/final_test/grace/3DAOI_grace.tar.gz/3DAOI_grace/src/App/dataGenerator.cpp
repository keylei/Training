#include "dataGenerator.hpp"

using namespace std;
using namespace App;
using namespace Job;

DataGenerator::DataGenerator()
{

}

DataGenerator::~DataGenerator()
{

}

void DataGenerator::generateJob(InspectionData &inspectionData,
                                MeasuredObj *measuredObjArr,
                                int arrSize)
{
    //>>>----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //step1. 设置body(测量对象的矩形框)信息

    //rime -1 为什么元件的坐标的最大值就直接超出了board的最大值
    //rime -1 为什么元件的大小的最大值就直接和board的最大值一样了
    //rime -1 元件不可能出现在原点的左下角

    double xCoordMax = 150.00; //元件中心点x坐标最大150.00
    double xCoordMin = 0.01;   //元件中心点x坐标最小0.01
    double yCoordMax = 150.00; //元件中心点y坐标最大150.00
    double yCoordMin = 0.01;   //元件中心点y坐标最小0.01
    double widthMax  = 100.00; //元件宽度最大100.00
    double widthMin  = 0.01;   //元件宽度最小0.01
    double heightMax = 100.00; //元件高度最大100.00
    double heightMin = 0.01;   //元件高度最小0.01
    char name[FILE_NAME_LEN];

    for (int i = 0; i < arrSize; ++i)
    {
        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //1.1 rectangle信息

        measuredObjArr[i].body().setXCoord(RANDOM_NUM(xCoordMax,xCoordMin));
        measuredObjArr[i].body().setYCoord(RANDOM_NUM(yCoordMax,yCoordMin));
        measuredObjArr[i].body().setWidth(RANDOM_NUM(widthMax,widthMin));
        measuredObjArr[i].body().setHeight(RANDOM_NUM(heightMax,heightMin));

        //>>>-------------------------------------------------------------------------------------------------------------------------------------
        //1.2 名字信息 前三分之一是"chip_"开头，后三分之二是"ic_"开头
        if(i < arrSize/3)//rime -1 这里比例也应该是提前定义好的呀，这是魔数
        {
            sprintf(name,"chip_%.3d",i);
        }
        else
        {
            sprintf(name,"ic_%.3d",i-arrSize/3);
        }
        measuredObjArr[i].setName(name);
        inspectionData.board().measuredObjList().pushTailNode(&measuredObjArr[i]);
    }

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //step2. 设置board(基板)信息

    double originalX = 10; //基板到原点的x距离
    double originalY = 10; //基板到原点的y距离
    double sizeX = 100; //基板宽
    double sizeY = 100; //基板长
    string defaultName = "Board"; //板名默认设置
    inspectionData.board().setName(defaultName);
    inspectionData.board().setOriginalX(originalX);
    inspectionData.board().setOriginalY(originalY);
    inspectionData.board().setSizeX(sizeX);
    inspectionData.board().setSizeY(sizeY);

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //step3. 设置version(版本)和lastEditingTime(时间)信息

    string version = "V1"; //默认版本设置
    inspectionData.setVersion(version);
    time_t currentTime = time(NULL); //设置当前时间
    tm * pCurTime = localtime(&currentTime);
    inspectionData.setLastEditingTime(asctime(pCurTime));
    //<<<----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
}
