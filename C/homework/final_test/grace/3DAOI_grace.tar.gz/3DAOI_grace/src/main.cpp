#include <iostream>

#include "SDK/customException.hpp"
#include "App/mainWindow.hpp"

using namespace std;

//rime -1 根目录下为什么没有lib目录
//rime -1 如何配置路径没有交代
//rime readme放在根目录就可以了

int main()
{
    try
    {
        //step1. 设置配置文件路径
        QString appSettingPath = "./Ini/appSetting.ini";
        QString captureSettingPath = "./Ini/captureSetting.ini";

        //step2. 加载配置文件
        App::MainWindow mainWindow; //rime -1 namespace在源文件中直接在一开始using就可以了
        mainWindow.loadAppSetting(appSettingPath);
        mainWindow.loadCaptureSetting(captureSettingPath);

        //step3. 加载程式
        //rime -1 讲过的问题 为什么讲过了还犯同样的错误， 既然是loadJobFolder，就干读的工作，其中还包含写，单一性何在
        mainWindow.loadJobFolder();
    }
    catch(const SDK::CustomException& ex) //打印捕获的异常
    {
        //rime -1 讲过的问题 为什么写了自定义异常还要这样抛异常
        std::ostringstream message;
        message << "File:"<<__FILE__<<"\n"
                << "Line:"<<__LINE__<<"\n"
                << "Func:"<<__FUNCTION__<<"\n"
                << " " << "\n"\
                << "Detail:"<<ex.what()<<"\n";
        std::cout << message.str();
    }

    return 0;
}
