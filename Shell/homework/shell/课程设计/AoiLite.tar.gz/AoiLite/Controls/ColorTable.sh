#!/usr/bin/env bash
#=========================================================================
# @usage
# @brief 不过是定义了颜色表而已
# @author
# @version 1.00 2017/08/24 note:create it
#=========================================================================

declare -i RED_COLOR=1                    # 红色背景代码
declare -i GREEN_COLOR=2                  # 绿色背景代码
declare -i YELLOW_COLOR=3                 # 黄色背景代码
declare -i BLUE_COLOR=4                   # 蓝色背景代码
declare -i FUCHSIA_COLOR=5                # 紫红色色背景代码
declare -i CYAN_COLOR=6                   # 青緑色背景代码
declare -i WHITE_COLOR=7                  # 白色背景代码
