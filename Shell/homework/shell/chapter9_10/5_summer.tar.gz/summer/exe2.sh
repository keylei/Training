#! /bin/bash
#===============================================================================
# -u, --user  功能为返回usernames.txt内的所有用户名，按行显示，每行显示5个，名称之间
#   用制表符tab分隔
#    例如：test.sh -u #后面不接参数
#       vincent    bob    byron    rime    plato
#         summer    peter    augus    grace    channing
#   -l, --login  功能为进入输入账户名和密码环节，如果账户错误有提示信息不存在，重新输入，
#      如果密码错误提示密码错误重新输入
#   如果连续输入两次错误，无论是账户名还是密码都将退出
#    例如：test.sh --login #无参数
#       请输入账户名：vincenr
#        账户不存在，请重新输入！
#        请输入账户名：vincent
#       请输入密码：*******
#        密码错误，请重新输入！
#        请输入密码：
#        登录成功！
#    -n, --number 功能为显示用户的ID号，即索引号
#   例如：test.sh -n vincent #必须接用户名
#        ID：1

#    -a, --age 功能为查询某用户名的年龄,默认值为第一个账户名的年龄

#    例如：test.sh -a  vincent
#         vincent's age is 24

#    --version  功能为查询脚本的版本
#    --help 为脚本的使用帮助，帮助简要写就可以
#===============================================================================
# allnumber是所有的行号
allnumber=`cat ./usernames.txt | grep -v "行号" |awk -F":" '{print $1}'`

#allusername是usernames.txt中所有的用户名
allusername=`cat ./usernames.txt | grep -v "用户名" |awk -F":" '{print $2}'`

#　定义allusername的所有名字为一个数组
array_name=${allusername[*]}

#allpasswd是usernames.txt中所有的用户密码
allpasswd=`cat ./usernames.txt | grep -v "用户密码" |awk -F":" '{print $3}'`

# 输入的第二个参数$2，赋值给inputusername
inputusername="$2"

eval set -- `getopt -o u::l::n:a:: -l user::,login::,number:,\
age::,version::,help:: -n 'exe2.sh' -- "$@"`

while true
do

 case "$1" in

  -u|--user)
   case "$2" in
    "")
    cat ./usernames.txt | grep -v "用户名" |awk -F":" '{print $2}' | paste \
     - - - - - -d '\t'
     shift
     ;;
    *)
     echo -e "\e[0;35m输入错误！\e[m"
     shift
     ;;
   esac
   ;;




  -l|--login)
  case "$2" in
   "")
   # 让循环判断输入用户名两次,num是循环的次数，不大于２，就是循环两次
   num=0
   while [ "$num" -lt 2 ]
   do
       echo -n -e "\033[45;39m请输入账户名(25秒内): \033[0m"
       # -t 25读取输入时间是25秒内
       read -t 25  inputuser
       cat ./usernames.txt|awk -F":" '{print $2}' | grep -wq "$inputuser" && echo
       if [[ $? -eq 0 ]]
       then
           echo
           # 让密码输入时候显示*来记录输入了多少位密码
           passwordModification()
           {
               password=''
               # 字背景颜色范围:40----49,字颜色:30-----------39
               echo -n -e "\033[47;34m 请输入密码(25秒内): \033[0m"
               while IFS= read -t 25 -r -s -n1 char
               do
                   if [ -z $char ]
                   then
                       echo
                       break
                   fi
                   if [[ $char == $'\x08' || $char == $'\x7f' ]]
                   then
                       [[ -n $password ]] &&  password=${password:0:$\
                       {#password}-1}
                       printf '\b \b'
                   else
                       password+=$char
                       printf '*'
                   fi
               done
           }
           passwordModification
           # 判断密码是否正确
           cat ./usernames.txt | grep -w "$inputuser"| awk -F":" '{print $3}'\
           |grep -w "$password" && echo
           if [[ $? -eq 0 ]]
           then
               echo -e "\033[44;30m登录成功！ \033[0m"
               break
           else
               echo -e "\033[43;30m密码错误，请重新输入！ \033[0m"
               echo
               second_passwd=''
               # second_passwd=''是第二次输入的密码            　
               echo -n -e "\033[41;36m 请第二次输入密码(25秒内): \033[0m "
               while IFS= read -t 25 -r -s -n1 char
               do
                   if [ -z $char ]
                   then
                       echo
                       break
                   fi
                   if [[ $char == $'\x08' || $char == $'\x7f' ]]
                   then
                       [[ -n $second_passwd ]] &&  second_passwd=${second_passwd\
                       :0:${#second_passwd}-1}
                       printf '\b \b'
                   else
                       second_passwd+=$char
                       printf '*'
                   fi
               done
               # 判断输入的密码是不是usernames.txt中对应用户的密码
               thesecond_passwd=`cat ./usernames.txt | grep -w "$inputuser"| \
               awk -F":" '{print $3}'|grep -w "$second_passwd" && echo ""`
               if [[ $? -eq 0 ]]; then
                   echo -e "\033[47;32m登录成功！\033[0m"
                   break
               else
                   echo -e "\033[41;30m第二次输入密码错误！\033[0m"
                   break
               fi
           fi
       else
           echo -e "\033[44;30m账户不存在，只能输入两次！\033[0m"
           echo
           let "num++"
       fi
   shift
   done
    ;;


    *)
    shift
    ;;
    esac
    ;;


   -n|--number)
   case "$2" in
   *)
   inputusername="$2"
   find_username=`cat ./usernames.txt | grep -w "$inputusername" `

   if [[ $? -eq 0 ]]; then
      find_username=`cat ./usernames.txt | grep -w "$inputusername"`
      ID=`cat ./usernames.txt | grep -w "$inputusername" | awk -F":" '{print $1}'`
      echo
      echo "$inputusername 的ID:"　$ID
   else
       echo -e "\033[45;31m没有你要查询ID的用户\033[0m"
   fi
   shift
   ;;
  esac
  ;;


  #    -a, --age 功能为查询某用户名的年龄,默认值为第一个账户名的年龄

  -a|--age)
  case "$2" in

   "")
   #　默认值为第一个账户名的年龄　
   # first_user是第一个账户名

    #first_user=`cat ./usernames.txt | awk -F":" '{print $2}' |  head -n 2　\
     #| tail -n 1`
    # first_age是第一的账户的年龄

    first_age=`cat ./usernames.txt | awk -F":" '{print $4}' | head -n 2 \
    | tail -n 1`
    echo "第一个用户的年龄："$first_age
    shift
    ;;


   *)
   # all_ageline是年龄的那一列的找到的所有年龄
   all_ageline=`cat ./usernames.txt |grep -v "年龄"| awk -F":" '{print $4}' `
   inputusername="$2"
   # isinusernames是是否输入了usernames.txt中的用户名

   isinusernames=`cat ./usernames.txt | grep -w "$inputusername" `
   if [[ $? -eq 0 ]]
   then
      age=`cat ./usernames.txt | grep -w "$inputusername" | awk -F":" '{print $4}'`
      echo
      echo "$inputusername 的年龄:"　$age
   else
       echo "输入错误！"
   fi
    shift
    ;;
  esac
  ;;

  #    --version  功能为查询脚本的版本
  --version)
  case "$2" in
      "")
      echo 当前的脚本的版本:`echo $SHELL`
      exit
      shift
      ;;
      *)
      echo "输入错误！"
      shift
      ;;
   esac
  ;;


  #    --help 为脚本的使用帮助
  --help)
  case "$2" in
      "")
      echo "******************************************************************"
      echo "必选参数对长短选项同时适用。"
      echo "exe2.sh的必选参数-n,--number"
      echo "exe2.sh的可选参数-u -a -l,--user，--age,--login,--version,--help"
      echo "-u, --user      返回usernames.txt内输出所有用户名"
      echo "-l, --login     进入输入账户名和密码环节"
      echo "-n, --number    显示用户的ID号"
      echo "-a, --age       查询某用户名的年龄,默认值为第一个账户名的年龄"
      echo "--version       查询脚本的版本"
      echo "--help          帮助了解exe2.sh脚本的信息"
      echo "******************************************************************"
       exit
      shift
      ;;
  esac
  ;;
  *)

  exit 1
  ;;
  esac
  shift
  done
