#! /bin/bash
#===============================================================================
# 1.账户名和密码从键盘输入，且密码不可见；
# 2.每次输入时间不能过长（比如一分钟）,可以循环输入，即可以不退出当前脚本输入N个账
# 	户及密码，退出按ctrl+c；
# 3.账户名称格式要求如下：
# （1）首字母必须是英文字母大写
# （2）账户名必须有数字和小写字母
# （3）不能包含除了英文字母及数字以外的字符
# （4）账户名必须连续不能间断,名称长度不小于5个字符，但也不能大于18个字符
# 4.密码格式要求如下：
#（1）密码开头必须是英文字母
#（2）密码由英文字母、数字、和符号点(.)下划线(_)组成
#（3）密码连续不能少于8位，但不能大于15位
#（4）所输入密码，必须保证数字一个，英文字母一个，点或下划线至少有其中一个
# 5.界面风格如下：
#
#    vincent@vincent Dir:~
#    ·····$passwd vincent
#    更改 vincent 的密码。
#   （当前）UNIX 密码：
#    输入新的 UNIX 密码：
#
#	6.输入完密码后，再追加输入年龄（使用正则表达式）
# （1）年龄必须是数字
# （2）最大值为150，最小值大于0的，即0岁是非法的，151岁也是非法的
# 7.将所输入的账户和密码存到名为usernames.txt文件中，以冒号‘：’隔开，一行一个账
# 户名称对应一个密码一个年龄（有序列号，同样以‘：’分割）
#===============================================================================
number=0                                              # 输出到usernames.txt的行号
echo -e "行号:用户名:用户密码:年龄"  >usernames.txt     # 输出到信息到usernames.txt
username=''                                           # 定义的是用户的名字
main()                                                #　主函数
{
while true
do

    getUsername()                                       #用户名函数
    {
    while true
    do
        # username是输入的用户名字
    read -t 25 -p  "请输入你的用户名(25秒内):" username
    if [ ! -n "$username" ]  					        # 判断输入参数是否为空
    then
        echo
        echo -e "\033[31m你输入为空,请重新输入请输入首字母大写，包含英文字母和数字! \
         \033[0m"
        continue
    fi

    if [[ $username =~ ^[a-z0-9] ]]  # 判断输入用户名是否是大写字母开头
    then
        echo
        echo -e "\e[0;35m请输入开头为大写字母的用户名！\e[m"
        echo
        continue
    fi

    if [[ $username =~ ^[A-Z] ]] && [[ $username =~ ^[A-Z]+[A-Za-z]$ ]]; then
        echo -e "\e[0;32m输入的用户名没有包含数字！\e[m"
        continue
    fi

    # 判断开头为大写或者小写字母，包含大小写字母和数字的用户名，其他输入提示错误
    if [[ $username =~ ^[A-Z] ]] && [[ $username =~ [A-Za-z]+ ]] \
    && [[ $username =~ [0-9]+ ]] && [[ $username =~ ^[A-Za-z0-9]{8,18}$ ]]
    then
       echo
       echo "用户名正确： $username "
       break								    #　跳出循环，不继续询问并输入用户名
    else
       echo -e "\e[0;36m你输入无效的用户名，请输入首字母大写，包含英文字母和数字!\e[m"
       echo
    fi

    done

    }
    getUsername


getpassword()                                    #　密码函数
{

while true
do
 read -t 25 -p "请输入密码(25秒内): "  -s password
if [ ! -n "$password" ]  						 # 判断输入的密码是否为空
then
    echo -e "\033[31m你输入为空,请重新输入请输入!! \033[0m"
    continue
fi
# 判断输入的密码必须保证数字一个，英文字母一个，点或下划线至少有其中一个且8到15位
if [[ $password =~ ^[A-Za-z] ]] && [[ $password =~ [0-9]+ ]] && [[ $password =~ \
 [._]+ ]] && [[ $password =~ ^[A-Za-z0-9._]{8,15}$ ]]
then
    echo
    echo "密码格式正确！"
else
	echo "密码输入格式错误，请重新输入！"
	echo
    continue
fi

    # 添加修改密码选项y是修改n或者其他输入是放弃修改
passwordModification()
{
        #statements
while true
do
echo
echo -n "是否要修改密码(y/n)："            #添加查询修改密码
read input
if [ ! -n "$input" ]  						 # 判断输入的密码是否为空
then
    echo -e "\033[31m你输入为空,请重新输入请输入!! \033[0m"
    continue
fi

if [ "$input" == y ]
then
    echo
    echo  "你修改的密码为:"
    read -s inputpassword              #读取为修改后的密码
               # 密码的格式还是跟上面的密码输入一样
               # 判断输入的密码必须保证数字一个，英文字母一个，点或下划线至少有其中一个且8到15位
    if [[ $inputpassword =~ ^[A-Za-z] ]] && [[ $inputpassword =~ [0-9]+ ]] && \
    [[ $inputpassword =~ [._]+ ]] && [[ $inputpassword =~ ^[A-Za-z0-9._]{8,15}$ ]]
    then
        local newpasswork=$inputpassword
        echo "你修改后的密码：$newpasswork	"
        password=$newpasswork              # 修改后的密码
        echo
        break

    else
        echo "你输入的修改密码格式不对，密码格式包含大小写数字.或者_！"
        echo
        continue
    fi

else
    echo "你已经放弃修改密码！"
    echo
    break
fi

done
}
passwordModification
break

done

}
getpassword


getAge()
{
while true
do
read  -t 25 -p  "请输入你的年龄(25秒内输入):" age
if [ ! -n "$age" ]  							# 判断输入参数是否为空
then
    echo -e "\033[31m你输入为空!!! \033[0m"
    continue
  # 判断参数位数是否不大于等于4个，因为０－１５０是三位数，避免输入了两个参数
fi

str=`echo $age | sed -e 's/[a-Z]//g'`			# 判断输入的参数是不是字符串
if [ -z $str ]
then
	echo -e "\e[0;34m你输入字符串！请输入0~150的整数\e[m"
	continue
fi

expr  $age + 1 2>/dev/null					#	判断输入参数是不是浮点数
if [ $? -ne 0 ]								#　判断上条语句的退出码是不是等于０
then
	echo -e "\e[0;33m你输入了浮点数，请重新输入！\e[m"
	continue
fi

if [[ $age =~ ^[0-9]+$ ]]
then
	if [ $age -gt 0 ] && [ $age -lt 150 ]
	then
	break
	else
	echo　-e "\e[0;37m你输入的年龄不在0到150之间!\e[m"
    continue
	fi
	echo "你输入的年龄非法！"
    continue
    echo
fi
done
}
getAge


let number++                                    #　让输出的行号递增
echo -e "$number:$username:$password:$age" >> usernames.txt
done
}
main
