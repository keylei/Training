#! /bin/bash
#===============================================================================
#二、创建一个脚本，此脚本具有以下options
#    -u, --user  功能为返回usernames.txt内的所有用户名，按行显示，每行显示5个，名称之间用制表符tab分隔
#    例如：test.sh -u #后面不接参数
#         vincent    bob    byron    rime    plato
#         summer    peter    augus    grace    channing
#    -l, --login  功能为进入输入账户名和密码环节，如果账户错误有提示信息不存在，重新输入，如果密码错误提示密码错误重新输入
#    如果连续输入两次错误，无论是账户名还是密码都将退出
#    例如：test.sh --login #无参数
#        请输入账户名：vincenr
#        账户不存在，请重新输入！
#        请输入账户名：vincent
#        请输入密码：*******
#        密码错误，请重新输入！
#        请输入密码：
#        登录成功！
#    -n, --number 功能为显示用户的ID号，即索引号

#    例如：test.sh -n vincent #必须接用户名
#         ID：1

#    -a, --age 功能为查询某用户名的年龄,如果没有输入默认值为第一个账户名的年龄

#    例如：test.sh -a  vincent
#         vincent's age is 24

#    --version  功能为查询脚本的版本
#    --help 为脚本的使用帮助，帮助简要写就可以

#===============================================================================

#将getopt命令来处理脚本的命令行选项和参数，再将处理后的结果重新复制给位置参数
#eval命令用于将其后的内容作为单个命令读取和执行，这里用于处理getopt命令生成的参数的转义字符
eval set -- `getopt -o uln:a:: --long user,login,number:,age::,version,help -n 'getopt_longopt.sh' -- "$@"`

#如果位置参数的个数大于0就执行while循环
while [ $# -gt 0 ]
do

case "$1" in
#第一个参数为u或--user时，每行输出5个用户且用TAB分隔。
#FS：分隔符；RS：记录行分隔符；ORS：可以看成RS的逆向过程；shift：参数移一位
  -u|--user)
    awk 'BEGIN{ FS=":" ;RS="\n" ;ORS=""; } { print $2"\t";if($1%5==0) print "\n"; }' usernames.txt
    shift
    ;;

#第一个参数为l或--login时，作用登录账号：输入账户名和密码相对应显示登录成功

#第一个while循环：作用读取用户账户名.grep行找到账户名在不在文件中在则输出到/dev/null
#不在则$?不是0，则输出账户不存在；在则退出循环
##第二个while循环：作用读取用户密码.grep行找到账户名和相应密码在不在文件中在则输出到/dev/null
#不在则$?不是0，则输出密码错误并重新输入密码再次进行判断；在则输出登录成功并且退出循环
  -l|--login)

    while :   #读取用户账户名     
    do
      read -p "请输入帐户名：" account
      grep -w $account usernames.txt >> /dev/null   
      if (( $? != 0 )) 
      then
        echo "账户不存在，请重新输入！"
      continue
      fi
      break
    done

      while :   #读取用户密码
      do
        read -sp "请输入账户密码:" password
        grep -w $account:$password usernames.txt >> /dev/null 
        if (( $? != 0 ))
        then
          echo -e "密码错误！"
          read -sp "请再次输入账户密码:" password1
          grep -w $account:$password1 usernames.txt >> /dev/null
          [ $? != 0 ] && echo -e "\n密码错误，请重新输入！"      
          continue
        fi
        echo -e "\n登陆成功"
        break
      done
    ;;

#第一个参数为n或--number时,显示用户ID。awk -v:传变量；-F：分隔符
  -n|--number)

#判断第二个参数，不输入第二个参数系统会默认有提示，输入参数则进行相应判断处理
    case "$2" in
    "")
      echo "wrong"
      shift
      ;;
    *)
      awk -v usrname=$2 -F: '{ if($2==usrname) print "ID:"$1 }' usernames.txt
      shift
      ;;
    esac
    ;;

#第一个参数为a或--age时,不带参数默认输出第一个账户名的年龄,带参数时输出相应年龄。
#NR==1第一行
  -a|--age)

    case "$2" in
      "")
        awk -F: NR==1'{ print $2"'\''s age is " $4 }' usernames.txt
        shift
        ;;
      *)
        awk -v usrnames=$2 -F: '{ if($2==usrnames) print $2"'\''s age is " $4 }' usernames.txt
        shift
        ;;
    esac 
    ;;

#第一个参数为--version时输出脚本的版本
  --version)
    echo "version=1.0"
    shift
    ;;

#第一个参数为--help时显示相关帮助信息
  --help)
    echo "-u，--user:无参，每行输出5个用户且用TAB分隔"
    echo "-l,--login:无参，登录：输入账户名和密码相对应显示登录成功"
    echo "-n,--number:带参，显示用户ID"
    echo "-a,--age:可带参数也可不带参数，不带参数默认输出第一个账户名的年龄"
    echo "--version:无参，查询脚本的版本"
    echo "--help:无参，输出脚本帮助信息"
    shift
    ;;

#第一个参数若为--退出while循环，表示选项的结束
  --)
    shift
    break
    ;;

#第一个参数若为其他选项，则显示错误信息，并退出脚本的执行
  *)
    echo "error!"
    exit 1
    ;;
    esac
    shift

done








