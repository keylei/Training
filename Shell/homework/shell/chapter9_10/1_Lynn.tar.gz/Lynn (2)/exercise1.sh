#! /bin/bash
################################################################################
#		作业要求：
#创建一个脚本实现记录账户名称和密码的功能，具体如下：
#			1.账户名和密码从键盘输入，且密码不可见；
#			2.每次输入时间不能过长（比如一分钟）,可以循环输入，即可以不退出当前脚本输入N个账户及密码，退出按ctrl+c；
#			3.账户名称格式要求如下：
# 		（1）首字母必须是英文字母大写
# 		（2）账户名必须有数字和小写字母
#			（3）不能包含除了英文字母及数字以外的字符
#     （4）账户名必须连续不能间断,名称长度不小于5个字符，但也不能大于18个字符
#    	4.密码格式要求如下：
#     （1）密码开头必须是英文字母
#     （2）密码由英文字母、数字、和符号点(.)下划线(_)组成
#     （3）密码连续不能少于8位，但不能大于15位
#     （4）所输入密码，必须保证数字一个，英文字母一个，点或下划线至少有其中一个
#     风格如下：
#        vincent@vincent Dir:~
#	    ·····$passwd vincent
#	    更改 vincent 的密码。
#       （当前）UNIX 密码： 
#        输入新的 UNIX 密码： 
#        
#    	5.输入完密码后，再追加输入年龄（使用正则表达式）
#     （1）年龄必须是数字
#     （2）最大值为150，最小值大于0的，即0岁是非法的，151岁也是非法的
#    	6.将所输入的账户和密码存到名为usernames.txt文件中，以冒号‘：’隔开，一行一个
#				账户名称对应一个密码一个年龄（有序列号，同样以‘：’分割）
#
################################################################################
declare dataFile=username.txt			#定义读入数据的文件
declare timeout=10								#定义read超时时间
declare erroredLimit=2						#初始化信息输入错误次数限制为2
declare ID=0											#初始化信息ID号为0
declare userAge
declare userName
declare userPassword


#写入数据函数：
writeDataToFile()
{
	echo -n "$ID:" >> $dataFile
	echo -n "$userName:" >> $dataFile
	echo -n "$userPassword:" >> $dataFile
	echo "$userAge" >> $dataFile
	echo -e "成功读入数据\n"
}

#读入年龄函数，由读入密码函数调用：
readAge()
{
	#从键盘读入年龄信息，并判断输入是否超时：
	if read -t $timeout -p "请输入年龄：" userAge
	then
		echo
		#判断输入的年龄是否合理：
		if [[ "$userAge" =~ (^1[0-4][0-9]$|^[1-9][0-9]$|^[1-9]$|150) ]]
		then
			(( ID++ ))
			#读入数据函数：
			writeDataToFile
			erroredLimit=0								#设置错误次数限制为0以退出循环
		else
			(( erroredLimit-- ))					#错误次数限制-1
			echo -e "年龄有误，请输入1-150间的数字\n"
		fi
	else
		echo -e "sorry,too slow\n"
		erroredLimit=0									#设置错误次数限制为0以退出循环
	fi
}


#读入密码函数，由读入用户名函数调用：
readPassword()
{	
	#从键盘读入密码信息，并判断输入是否超时：
	if read -s -t $timeout -p "请输入密码：" userPassword
	then
		echo
		#判断密码是否合理：
		if [[ "$userPassword" =~ ^[A-Za-z][A-Za-z0-9._]{7,14}$ ]] && \
			 [[ "$userPassword" =~ [0-9]+ ]] && \
			 [[ "$userPassword" =~ [_.]+ ]]

		then
			#声明用于第二次输入密码的局部变量：
			local checkingPassword
			if read -s -t $timeout -p "请再次输入密码：" checkingPassword
			then
				#判断两次输入的密码是否相同：
				if [[ "$checkingPassword" = "$userPassword" ]]
				then
					echo -e "\n密码设置成功，请妥善保管密码"
					erroredLimit=2											#将错误次数限制重置为2
					while [[ $erroredLimit -gt 0 ]]			#当错误限制大于0，进入读年龄函数
					do
						readAge
					done
				else
					(( erroredLimit-- ))								#错误次数限制-1
					echo -e "\n两次密码输入不一致！\n"
				fi
			else
				echo -e "\nsorry,too slow\n"
			fi

		else
			(( erroredLimit-- ))										#错误次数限制-1
			echo -e "\n请输入合法的密码,密码格式如下："
			echo "（1）密码开头必须是英文字母"
			echo "（2）密码由英文字母、数字、和符号点(.)下划线(_)组成"
			echo "（3）密码连续不能少于8位，但不能大于15位"
			echo -e "（4）必须保证数字一个，英文字母一个，点或下划线至少有其中一个\n"
		fi
	else
		echo
		echo -e "sorry,too slow\n"
		break
	fi
}


#读入用户名函数：
readUserName()
{
	#从键盘读入用户名，并判断是否超时：
	if read -t $timeout -p "请输入账户名：" userName
	then
		#判断用户名是否合理：
		if [[ "$userName" =~ ^[A-Z][A-Za-z0-9]{4,17}$ ]] && \
			 [[ "$userName" =~ [0-9]+ ]] && [[ "$userName" =~ [a-z]+ ]]
		then
			#判断用户名是否已存在：
			if [[ $userName =~ (`awk -F: '{printf "^"$2"$""|"}' $dataFile`"\n") ]]
			then
				echo "用户名已存在"
			else
				echo "用户名可用"
				erroredLimit=2												#将错误次数限制重置为2
				while [[ $erroredLimit -gt 0 ]]				#当错误限制大于0，进入读密码函数
				do
					readPassword
				done
			fi
			
		else
			echo -e "\n请输入合法的用户名,账户名称格式如下:"
			echo "(1）首字母必须是英文字母大写"
			echo "(2）账户名必须有数字和小写字母"
			echo "(3）不能包含英文字母及数字以外的字符"
			echo -e "(4）账户名不能间断,名称长度为5-18\n"
		fi
	else
		echo -e "sorry,too slow\n"
	fi
}


#主函数：
main()
{
	#判断是否已存在数据文件，若存在则根据文件最后一行的ID更新ID号：
	if [ -f $dataFile ]
	then
		ID=`tail -n 1 $dataFile | awk -F ':' '{print $1}'`
	else
		>> $dataFile
	fi

	echo "输入 ctrl+c 退出用户创建"
	while true												#循环输入信息：
	do
		readUserName										#调用读入用户名函数
	done
}
main
