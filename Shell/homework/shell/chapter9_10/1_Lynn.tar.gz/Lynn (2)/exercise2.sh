#! /bin/bash
#	练习要求：	
#		创建一个脚本，此脚本具有以下options
#		-u,	--user  功能为返回usernames.txt内的所有用户名，按行显示，每行显示5个，名称
#								之间用制表符tab分隔
#        
#  				      例如：test.sh -u #后面不接参数
#         				    vincent	bob	byron	rime	plato
#         				    summer	peter	augus	grace	channing
#             
# 	-l, --login	功能为进入输入账户名和密码环节，如果账户错误有提示信息不存在，重新输
#								入，如果密码错误提示密码错误重新输入,如果连续输入两次错误，无论是账
#								户名还是密码都将退出      
#            
#   -n, --number 功能为显示用户的ID号，即索引号
#        
#		-a, --age 功能为查询某用户名的年龄,如果没有输入默认值为第一个账户名的年龄
#        
#   --version  功能为查询脚本的版本
#
#   --help		 为脚本的使用帮助，帮助简要写就可以
################################################################################
souceFile=username.txt		#定义信息存储文件变量

#使用getopt命令来处理脚本的选项和参数，再将处理后的结果重新赋给位置参数，eval用于处
#理getopt生成的参数和转义字符：
eval set -- `getopt -o uln:a:: --long user,login,number:,age::,version,help -- "$@"`

>> $souceFile							#若信息存储文件不存在则新建该文件

while true
do
	case "$1" in
		#-n, --number 功能为显示用户的ID号，即索引号
		-n|--numer)
			case "$2" in
				"")
					echo "选项需要一个ID号作为参数"
					shift
				;;
				*)
					#判断用户名是否存在：
					if [[ "$2" =~ (`awk -F: '{printf "^"$2"$""|"}' $souceFile`"\n") ]] 
					then	
						echo -n "$2 的ID号为："					
						grep $2 $souceFile | awk -F ':' '{print $1}'		#打印对应用户名的ID
					else
						echo "用户名不存在"
					fi
					shift
				;;
			esac
		;;
		
		#-u,--user:功能为返回usernames.txt内的所有用户名，按行显示，每行显示5个，名称之
		#间用制表符tab分隔
		-u|--user)
			awk -F ':' '{print $2}' $souceFile | paste - - - - -	#paste语句为分五列打印
		;;

		#-l, --login  功能为进入输入账户名和密码环节
		-l|--login)
			#定义密码错误次数限制变量：
			errorLimit=2

			while true
			do
				if read -p "请输入用户名：" username		
				then
					#判断用户名是否在信息存储文件中存在：
					if [[ "$username" =~ (`awk -F: '{printf "^"$2"$""|"}' $souceFile`"\n") ]]
					then
						echo "用户名正确"
							errorLimit=2

							while [[ $errorLimit -gt 0 ]]		#判断输入密码错误次数限制是否大于0
							do	
								read -s -p "请输入密码:" password
								#判断密码是否正确：
								if [[ "$password" == `grep $username $souceFile | awk -F: '{print $3}'` ]]
								then
									echo -e "\n登陆成功"
									break 2											#跳出循环
								else
									echo -e "\n密码错误"
									(( errorLimit-- ))					#密码输入错误次数限制减1
								fi
							done
					else
						echo -e "用户名错误"
					fi
				fi
			done
		;;

		#-a, --age 功能为查询某用户名的年龄,如果没有输入默认值为第一个账户名的年龄
		-a|--age)
			#初始化用户名默认为数据文件中第一行的用户名
			username=`head -n 1 $souceFile | awk -F ':' '{print $2}'`

			case "$2" in
			"")
				shift
			;;
 
			*)
				#判断位置参数指定的用户名是否存在：
				if [[ "$2" =~ (`awk -F: '{printf "^"$2"$""|"}' $souceFile`"\n") ]]
				then
					username=$2							#将用户名变量重新赋值为位置参数指定用户名
				else
					echo "不存在用户名$2"
				fi
					shift
			;;
			esac

			#在屏幕打印年龄信息：
			echo -n "${username}'s age is "
			grep $username $souceFile | awk -F ':' '{print $4}'
		;;

		#--version  功能为查询脚本的版本:
		--version)
			echo "${0##*/} version 1.0"
		;;

		#--help		 脚本的使用帮助:
		--help)
			echo "${0##*/} 使用帮助:"
			echo "-u, --user  	返回usernames.txt内的所有用户名"
			echo "-l, --login 	进入输入账户名和密码环节"
			echo "-n, --number 	显示用户的ID号"
			echo "-a, --age 	查询用户的年龄"
			echo "--version	查询脚本的版本"
		;;

		#若为--选项，退出脚本:
		--)
			shift
			break
		;;

	esac
	shift														#每次运行完一个参数，参数左移一个，以运行下个参数
done
