#! /bin/bash

#==============================================================================
#二、创建一个脚本，此脚本具有以下options
#	-u, --user  功能为返回usernames.txt内的所有用户名，按行显示，每行显示5
#	个，名称之间用制表符tab分隔
#		例如：test.sh -u #后面不接参数
#    		vincent	bob	byron	rime	plato
#		summer	peter	augus	grace	channing
#
#	-l, --login  功能为进入输入账户名和密码环节，如果账户错误有提示信息不存
#	在，重新输入，如果密码错误提示密码错误重新输入,如果连续输入两次错误，无
#	论是账户名还是密码都将退出
#		例如：test.sh --login #无参数
#		请输入账户名：vincenr
#    		账户不存在，请重新输入！
#		请输入账户名：vincent
#		请输入密码：*******
#		密码错误，请重新输入！
#		请输入密码：
#		登录成功！
#
#	-n, --number 功能为显示用户的ID号，即索引号
#		例如：test.sh -n vincent #必须接用户名
#     		ID：1
#
#	-a, --age 功能为查询某用户名的年龄,如果没有输入默认值为第一个账户名的年龄
#		例如：test.sh -a  vincent
#     		vincent's age is 24
#	--version  功能为查询脚本的版本
#	--help 为脚本的使用帮助，帮助简要写就可以
#==============================================================================

APP_NAME="${0##*[\\/]}"                         #定义变量:脚本名称
APP_VERSION="1.0"                               #定义变量:版本号
TMOUT=60                                        #设置timeout时间为60秒
declare userName                                #用户名
declare userAge                                 #用户年龄
declare filePath="usernames.txt"                #读取文件的路径

Error=$'\033[41mError\033[0m'                   #显示红色Error
Success=$'\033[42mSuccess\033[0m'               #显示绿色Success

function Usage()                                #函数:显示帮助信息
{
    echo "  Usage:$APP_NAME"                    #脚本名称及帮助信息
    echo "  $APP_NAME [options]...[argument]..."
    echo
    echo "  -u,--user               display all user"
    echo "  -l,--login              login system"
    echo "  -n,--number=userName    display user id"
    echo "  -a,--age=userName       display user age"
    echo
    echo "     --help               display this help"
    echo "     --version            display version information"
}

function loginSys()                             #函数：登录系统
{
    local loginName                             #登录用户名
    local passwdTimes=3                         #设置输入密码次数
    local currentPasswdTimes=1                  #设置当前输入密码次数

    clear                                       #清屏并打印提示信息
    echo -e "\033[46m=======login system=======\033[0m"
    echo -en "\033[30;47mUsername:\033[0m"
    tput sc                                     #保存光标
    while true
    do
        read enter                              #获得键盘输入
        #判断键盘输入是否是注册用户名，返回匹配到底用户名给loginName
        loginName=$(awk -F: '{ if ($2=="'$enter'") print $2 }' $filePath)
        if [ -z $loginName ]                    #判断返回的loginName是否为空
        then
            #空则打印错误信息”不存在的用户名“
            echo -e "\033[41mError\033[0m Account does not exist!"
            echo -en "Enter again:"
        else
            tput rc                             #恢复光标
            tput ed                             #删除光标以后的内容
            #打印”用户名正确“
            echo -e "\033[42mSuccess\033[0m Username is right!"
            break                               #跳出”输入用户名“循环
        fi
    done

    echo -en "\033[30;47mPassword:\033[0m"          #打印提示信息
    tput sc                                         #保存光标
    while [ $currentPasswdTimes -le $passwdTimes ]  #判断输入密码次数是否到达上限
    do
        read -s enter                               #获得键盘输入
        #判断输入用户名的密码是否正确，并返回密码给loginPasswd
        loginPasswd=$(awk -F: \
            '{ if($2=="'$loginName'" && $3=="'$enter'") print $3}' $filePath)
        if [ -z $loginPasswd ]                      #判断密码返回值是否为空
        then
            #空则打印错误信息“密码错误”，并提示在输一遍
            echo -e "\n\033[41mError\033[0m Password is wrong!"
            echo -en "Enter again:"
            let currentPasswdTimes++                #输入密码次数加一
        else
            tput rc                                 #恢复光标位置
            tput ed                                 #删除光标后面的内容
            echo -e "\033[42mSuccess\033[0m Login!" #打印登录成功信息
            break                                   #跳出”输入密码“循环
        fi

        if [ $currentPasswdTimes -gt $passwdTimes ] #判断密码输入次数是否超过上限
        then
            tput rc                                 #恢复光标位置
            tput ed                                 #清除光标后的内容
            #打印提示信息”输入错误密码超过3次”，按“y”继续，按其他按键退出
            echo -e "\033[41mError\033[0m Wrong password 3 times!"
            echo -n "Please input \"y\" to continue,others to exit:"
            read enter
            #按Y则递归调用loginSys，按其他按键则跳出循环
            [[ $enter == "y" ]] && loginSys || break
        fi
    done
}

#定义选项参数,短选项、长选项、脚本名称
eval set -- `getopt -o uln:a::\
            --long user,login,number:,age::,help,version\
            -n "ex_2.sh" -- "$@"`
while true
do
    case "$1" in
    #用户信息
    -u|--user)
        #每隔5个用户名折行
        awk -F: '{ if ((NR+4)%5==0) print "" };\
            { printf $2"\t" } END {print ""}' $filePath
        ;;

    #登录信息,调用登录系统函数
    -l|--login)
        loginSys
        ;;

     #打印ID信息
    -n|--number)
        #传入用户名参数,检查该用户名并返回ID号
        userName=$2
        userID=$(awk -F: '{ if ($2=="'$userName'") print $1}' $filePath)
        #判断ID号,非空则打印该ID号的信息，空则打印没有对应用户名
        if [ -n "$userID" ]
        then echo "$userName ID:$userID"
        else echo "\"$userName\" is not sign in!"
        fi
        shift
        ;;

    #打印年龄信息
    -a|--age)
        #传入用户名参数,检查该用户名并返回年龄
        userName=$2
        userAge=$(awk -F: '{ if ($2=="'$userName'") print $4}' $filePath)
        #判断用户名为空则打印默认年龄信息(第一条)
        if [ -z $userName ]
        then awk -F: '{ if ($1==1) print $2"'\''s age is "$4}' $filePath
        else
            #判断用户年龄是否为空,空则打印没有对应的用户名,非空则打印该用户年龄
            if [ -z $userAge ]
            then echo "\"${userName}\" is not sign in!"
            else echo "${userName}'s age is ${userAge}!"
            fi
        fi
        shift
       ;;

    #打印帮助信息
    --help)
        Usage
        ;;

    #打印版本信息
    --version)
        echo "Version:$APP_VERSION"
        ;;

    #选项循环结束
    --)
        shift
        break
        ;;

    #错误信息
    *)
        echo "Try \"./$APP_NAME --help\" for more information"
        exit 1
        ;;

    esac
    shift
done
