#! /bin/bash

#==============================================================================
# 一、创建一个脚本实现记录账户名称和密码的功能，具体如下：
#	1.账户名和密码从键盘输入，且密码不可见；
#	2.每次输入时间不能过长（比如一分钟）,可以循环输入，即可以不退出当前脚本
#	  输入N个账户及密码，退出按ctrl+c；
#	3.账户名称格式要求如下：
#	 （1）首字母必须是英文字母大写
#	 （2）账户名必须有数字和小写字母
#	 （3）不能包含除了英文字母及数字以外的字符
#	 （4）账户名必须连续不能间断,名称长度不小于5个字符，但也不能大于18个字符
#	4.密码格式要求如下：
#	 （1）密码开头必须是英文字母
#	 （2）密码由英文字母、数字、和符号点(.)下划线(_)组成
#	 （3）密码连续不能少于8位，但不能大于15位
#	 （4）所输入密码，必须保证数字一个，英文字母一个，点或下划线至少有其中一
#	      个风格如下：
#		vincent@vincent Dir:~
#		·····$passwd vincent
#		更改 vincent 的密码。
#		(当前)UNIX 密码：
#		输入新的 UNIX 密码：
#	5.输入完密码后，再追加输入年龄（使用正则表达式）
#	 （1）年龄必须是数字
#	 （2）最大值为150，最小值大于0的，即0岁是非法的，151岁也是非法的
#	6.将所输入的账户和密码存到名为usernames.txt文件中，以冒号‘：’隔开，一行
#	  一个账户名称对应一个密码一个年龄（有序列号，同样以‘：’分割）
#==============================================================================

[ ! -f usernames.txt ] && >usernames.txt    #判断文件是否存在,没有则创建
output="usernames.txt"                      #账户密码年龄输出到的文件名
userNum=$(awk 'END{ print NR }' $output)    #已注册账户数量
enterTime=60                                #设置输入时间

Error=$'\033[41mError\033[0m'               #显示红色Error
Success=$'\033[42mSuccess\033[0m'           #显示绿色Success


#函数:通过传入参数,检查传入参数是否符合要求
function checkAccount()
{
    local userName=$1                       #定义本地变量:用户名
    local oldUser=$(awk -F: '{if ($2=="'$userName'")\
                  print $2}' $output)       #搜索文件中的重复用户名
    if [[ $userName = "" ]]                 #输入为空
    then
        echo -e $Error" Account is empty!Please input user name!"
    elif [[ $userName = $oldUser ]]         #重复用户名
    then
        echo -e $Error" Same account name!"
    elif [[ ! $userName =~ ^[A-Z] ]]        #首字符不是英文大写
    then
        echo -e $Error" Account name first character must be capital!"
    elif [[ ! $userName =~ [0-9]+ ]]        #用户名不包含数字
    then
        echo -e $Error" Account name must contain numbers!"
    elif [[ ! $userName =~ [a-z]+ ]]        #用户名不包含小写字母
    then
        echo -e $Error" Account name must contain lowercase letters!"
    elif [[ $userName =~ [^[:alnum:]] ]]    #用户名包含特殊字符
    then
        echo -e $Error" Illegal character!Please input letters and numbers!"
    elif [[ ${#userName} -lt "5" ]]         #用户名长度过短
    then
        echo -e $Error" Account name length must longger than 4!"
    elif [[ ${#userName} -gt "18" ]]        #用户名长度过长
    then
        echo -e $Error" Account name length must shorter than 19!"
    else
        echo -e $Success" Legal user name!"
        echo "-------------------------------------------------"
        break                               #跳出函数
    fi
}


#函数:通过传入参数,检查传入参数是否符合要求
function checkPasswd()
{
    local userPasswd=$1                         #定义本地变量:密码

    if [[ $userPasswd = "" ]]                   #输入为空
    then
        echo -e "$Error Password is empty!Please input psswd!"
        return 1
    elif [[ ! $userPasswd =~ ^[[:alpha:]]. ]]   #首字符不是英文
    then
        echo -e $Error" Password first character must be letter!"
        return 1
    elif [[ ! $userPasswd =~ [0-9] ]]           #密码未包含数字
    then
        echo -e $Error" Password must contain numbers!"
        return 1
    elif [[ ! $userPasswd =~ [._] ]]            #密码未包含.或_
    then
        echo -e $Error" Password must contain \".\" or \"_\"!"
        return 1
    elif [[ $userPasswd =~ [^[:alnum:]._]+ ]]   #密码包含特殊字符
    then
        echo -e $Error" Illegal character!Please input letters and numbers!"
        return 1
    elif [[ ${#userPasswd} -lt "8" ]]           #密码长度过短
    then
        echo -e $Error" Password length must longger than 7!"
        return 1
    elif [[ ${#userPasswd} -ge "15" ]]          #密码长度过长
    then
        echo -e $Error" Password length must shorter than 16!"
        return 1
    else
        return 2
    fi
}


#函数:通过传入参数,检查传入参数是否符合要求
function checkAge()
{
    local userAge=$1                            #定义本地变量:年龄

    if [[ $userAge = "" ]]                      #输入为空
    then
        echo -e $Error" User age is empty!Please input your age!"
    elif [[ $userAge =~ [^0-9]+ ]]              #年龄必须是数字
    then
        echo -e $Error" Please input your age in digit!"
    elif [[ ${userAge} -lt "1" ]]               #年龄小于0
    then
        echo -e $Error" Please input your age bigger than 0!"
    elif [[ ${userAge} -gt "150" ]]             #年龄大于150
        then
            echo -e $Error" Please input your age smaller than 151!"
        else
            echo -e $Success" Legal user age!"
            echo "-------------------------------------------------"
            break                               #跳出
        fi
}

#开始程序
while true                                      #循环输入账户名-密码-年龄
do

    clear
    echo "
1.账户名称格式要求如下：
  (1)首字母必须是英文字母大写
  (2)账户名必须有数字和小写字母
  (3)不能包含除了英文字母及数字以外的字符
  (4)账户名必须连续不能间断,名称长度5-18
2.密码格式要求如下：
  (1)密码开头必须是英文字母
  (2)密码由英文字母、数字、和符号点(.)下划线(_)组成
  (3)密码连续不能少于8位，但不能大于15位
  (4)密码包含数字一个，英文字母一个，点或下划线一个
3.按Ctrl+C退出"
    echo -e "\033[46m=====registered account&press ctrl+c to exit=====\033[0m"

    while true                                  #注册账户名
    do
        echo -en "Enter User name:"
        if read -t $enterTime userName          #从键盘获得账户名并判断是否超时
        then
            checkAccount $userName              #调用函数,检查账户名是否合法
        else
            echo "Time out"
        fi
    done


    while true                                  #确认密码
    do
        echo -en "Enter Password:"
        if read -t $enterTime -s userPasswd     #从键盘获取密码,判断是否超时
        then
            echo
            checkPasswd $userPasswd             #调用函数,检查密码是否合法
        else
            echo "Time out!"
        fi

        if [ $? = 2 ]                           #判断函数返回值是否为2
        then
            echo -en "Password again:"
            read -t $enterTime -s nextPasswd    #再次从键盘获取密码,与第一次比较
            echo
            if [ "$userPasswd" = "$nextPasswd" ] #判断两次密码输入是否相同
            then
                echo -e $Success" Legal user password!"
                echo "-------------------------------------------------"
                break                           #如果相同,退出循环
            else
                echo -e "Two different input!"  #如果不相同,打印信息
            fi
        fi
    done


    while true                                  #输入年龄
    do
        echo -en "Enter your age:"
        if read -t $enterTime userAge           #从键盘获取年龄,并判断是否超时
        then
            checkAge $userAge                   #调用函数,检查年龄是否合法
        else
            echo "Time out!"
        fi
    done

    let userNum++                               #注册账户序号增加,并输出注册信息
    echo "$userNum:$userName:$userPasswd:$userAge" >> $output
done
