#! /bin/bash
################################################################################
# 二、创建一个脚本，此脚本具有以下options
#		-u, --user  功能为返回usernames.txt内的所有用户名，按行显示，每行显示5个，
#	  						名称之间用制表符tab分隔
#    								例如：test.sh -u #后面不接参数
#         					  		vincent	bob		byron	rime	plato
#        						  		summer	peter	augus	grace	channing
#   -l, --login  功能为进入输入账户名和密码环节，如果账户错误有提示信息不存在，
#								 重新输入，如果密码错误提示密码错误重新输入,如果连续输入两次错误，
#								 无论是账户名还是密码都将退出
#    									例如：test.sh --login #无参数
#    												请输入账户名：vincenr
#        										账户不存在，请重新输入！
#        										请输入账户名：vincent
#        										请输入密码：*******
#        										密码错误，请重新输入！
#        										请输入密码：
#        										登录成功！
#    -n, --number 功能为显示用户的ID号，即索引号
#    									例如：test.sh -n vincent #必须接用户名
#         	 						ID：1
#  	 -a, --age 		功能为查询某用户名的年龄,如果没有输入默认值为第一个账户名的年龄
#    									例如：test.sh -a  vincent
#         									vincent's age is 24
#    --version  	功能为查询脚本的版本
#    --help 		 	功能为脚本的使用帮助，帮助简要写就可以
#		注意
#				1.两个脚本注意防呆，和提示信息的人性化
#				2.注意变量的命名，版面及格式，脚本的名称也要有意义
#				3.注释要简洁，语义明确
################################################################################

#定义从键盘读取的变量accountName和password来记录输入的账户名和密码
declare accountName password

#定义函数checkAccount，用来核对输入的账户名是否存在
checkAccount()
{
		cat usernames.txt|grep -v Num|tr '：' ' '|awk '{print $2}'|grep -w $accountName
}
#定义函数checkPassword，找出输入的账户名对应的密码，用来核对输入的密码是否正确
checkPassword()
{
		cat usernames.txt|grep -v Num|tr '：' ' '|grep -w $accountName|awk '{print $3}'
}
#定义函数inputPassword，进入输入密码环节，判断连续两次输入密码的情况
inputPassword()
{
		echo -n "请输入密码："
		read -s password			#隐藏输入的密码
		echo

	#若记录的密码字段不能与输入的密码匹配
	if [[ "$(checkPassword)" != "$password" ]] > /dev/null 2>&1
	then
			echo -e "密码错误，请重新输入！\n"
			echo -n "请输入密码："
			read -s password		#隐藏输入的密码
			echo

			#重新输入，第二次判断密码是否正确
			if [[ "$(checkPassword)" != "$password" ]] > /dev/null 2>&1
			then
					exit		#连续两次输入错误就退出程序
			else
					echo "登录成功！"
			fi

	#否则为匹配成功
	else
			echo "登录成功！"
	fi
}


#使用getopt命令来处理脚本的命令行选项和参数，再将处理后的结果重新赋值给位置参数
#eval将其后的内容作为单个命令读取和执行，这里用于处理getopt命令生成的参数的转义字符
eval set -- `getopt -o uln:a:: --long user,login,number:,age::,version,help \
-n 'options_2.sh' -- "$@"`

#执行while循环
while true
do
		case "$1" in

		-u|--user)
				#找出usernames.txt的所有用户名，每行显示5个，用制表符tab分隔
				cat usernames.txt|grep -v Num|tr '：' ' '|awk '{print $2}'| \
				paste -d'\t' - - - - -
	 			;;

		-l|--login)
				#进入输入账户名环节，判断连续两次输入账户名的情况
				echo -n "请输入账户名："
				read accountName

				#若输入的账户名核对为空
				if [[ "$(checkAccount)" == "" ]] > /dev/null 2>&1
				then
						echo -e "账户不存在，请重新输入！\n"
						echo -n "请输入账户名："
						read accountName

						#重新输入，第二次判断账户名是否存在
						if [[ "$(checkAccount)" == "" ]] > /dev/null 2>&1
						then
								exit			#连续两次输入错误就退出程序
						else
								inputPassword			#输出正确则调用函数inputPassword，继续输入密码
						fi

				#输出正确则调用函数inputPassword，继续输入密码
				else
						inputPassword
				fi
	 			;;

		-n|--number)
				case "$2" in
				"")			#选项没有指定参数，则跳过
		 				shift
		 				;;
				*)			#选项指定了参数，则输出账户名对应的ID号
		 				num=$(cat usernames.txt|grep -v Num|tr '：' ' '|grep -w $2|awk '{print $1}')
						echo "ID：$num"
		 				shift
		 				;;
	 			esac
	 			;;

		-a|--age)
				case "$2" in
				"")		#当没有给具有可选参数的选项-a|--age指定参数时，默认输出第一个账户的年龄
						age=$(cat usernames.txt|grep -v Num|tr '：' ' '|head -1|awk '{print $4}')
						echo "$2's age is $age"
						shift
						;;
				*)		#指定参数后，显示输入的账户名对应的年龄
						age=$(cat usernames.txt|grep -v Num|tr '：' ' '|grep -w $2|awk '{print $4}')
						echo "$2's age is $age"
						shift
						;;
				esac
	 			;;

		--version)	#查询脚本的版本
				echo "util-linux 2017.8.21"
				;;

		--help)			#脚本的使用帮助
				echo "	-u, --user	显示所有用户名，每行5个，制表符分隔"
				echo "	-l, --login	输入账户名和密码登录，连续两次输入错误即退出"
				echo "	-n, --number	显示用户的ID号，即索引号"
				echo "	-a, --age	查询年龄，没有输入则默认为第一个账户名年龄"
				echo "	--version	查询脚本的版本"
    		echo "	--help		脚本的使用帮助"
				;;

		--)			#此选项则退出while循环，表示选项的结束
	 			shift
	 			break
	 			;;

		*)			#若为其他选项，显示错误信息并退出脚本的执行
	 			echo "无效选项"
	 			exit 1
	 			;;
		esac
		shift
done
